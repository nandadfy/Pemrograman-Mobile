import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Informasi Buku',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: const MyHomePage(title: 'Book Information'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: <Widget>[
          const SizedBox(height: 20),
          Text(
            'Nama: Nanda Dwi Febriyanti',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'NIM: 123210187',
            style: TextStyle(fontSize: 16),
          ),


          const SizedBox(height: 20),
          Text(
            'Judul Buku: Pulang',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          Text(
            'Penulis: Tere Liye',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          Text(
            'ISBN: 9786020822129',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // Action for Button 1
            },
            child: const Text('Tambah ke Keranjang'),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              // Action for Button 2
            },
            child: const Text('Beli Sekarang'),
          ),
          const SizedBox(height: 20),
          TextField(
            decoration: InputDecoration(
              labelText: 'Masukkan ulasan Anda',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Image.asset(
            'android/assets/pulang.jpeg', // Ubah dengan path gambar Anda
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          Image.asset(
            'android/assets/pulangg.jpeg', // Ubah dengan path gambar Anda
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          Image.asset(
            'android/assets/pulanggg.jpg', // Ubah dengan path gambar Anda
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          Image.asset(
            'android/assets/pulangggg.jpg', // Ubah dengan path gambar Anda
            fit: BoxFit.cover,
          ),
        ],
      ),
    );
  }
}
